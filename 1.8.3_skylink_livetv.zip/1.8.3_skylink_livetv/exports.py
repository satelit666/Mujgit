import datetime
import io
import re

html_escape_table = {
    "&": "&amp;",
    '"': "&quot;",
    "'": "&apos;",
    ">": "&gt;",
    "<": "&lt;",
}


def html_escape(text):
    if not text:
        return ""
    return "".join(html_escape_table.get(c, c) for c in text)


def logo_id(title):
    for ch in [" ", "/", "(18+)", ":"]:
        title = title.replace(ch, "")
    return title.replace("+", "plus").lower() + ".png"


def logo_sl_location(title):
    replacements = {":": "", "/": "", "+": "", " ": "%20"}
    for ch in replacements.keys():
        title = title.replace(ch, replacements[ch])
    return "mmchan/channelicons/" + title + "_w267.png"


def create_m3u(channels, path, logo_url=None):
    m3u = "#EXTM3U\n"
    for ch in channels:
        ch_id = ch["id"]
        title = ch["title"]
        icon_url = ch.get("icon", "")
        pin_protected = ch.get("pinProtected", False)
        replay_days = ch.get("replayDays", 0)
        askpin = "True" if pin_protected else "False"

        # Convert icon URL to filename (e.g., "m1hd_w56.png")
        #tvg_logo = icon_url.split("/")[-1] if "_m.png" in icon_url else ""
        tvg_logo = re.sub(r'[^\w\-_. ]', '_', title.strip()) + ".png" if "_m.png" in icon_url else ""
        
        # EXTINF line
        line = f'#EXTINF:-1 tvg-id="{ch_id}" tvg-logo="{tvg_logo}"'
        if ch.get("replay", False):
            line += f' catchup-days="{replay_days}" catchup-type="default" catchup-source="plugin://plugin.video.directone/?stationid={ch_id}&askpin={askpin}&catchup_id={{catchup-id}}"'
        line += f',{title}\n'

        # Plugin URL
        line += f'plugin://plugin.video.directone/?id={ch_id}&askpin={askpin}\n'

        m3u += line

    with io.open(path, "w", encoding="utf8") as file:
        file.write(m3u)



def create_epg(channels, epg, path):
    
    
    with io.open(path, "w", encoding="utf8") as file:
        file.write(epg)


