# -*- coding: utf-8 -*-
# Author: Spejlo
# Created on: 24.03.2026
import os

import xbmcaddon
import xbmcgui


def set_isa():
    _self = xbmcaddon.Addon(id="plugin.video.directone")
    try:
        _isa = xbmcaddon.Addon(id="inputstream.adaptive")
    except:
        xbmcgui.Dialog().ok(_self.getAddonInfo("name"), _self.getLocalizedString(30392))
        return

    if _self.getSetting("isa_prompt") == "false":
        return
    if _isa.getSetting("adaptivestream.res.max") == "720p":
        return

    _r = xbmcgui.Dialog().yesnocustom(_self.getAddonInfo("name"), _self.getLocalizedString(30109), "Don't Ask Again",defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
    if _r == 1:
        _isa.setSetting("adaptivestream.res.max", "720p")
        _isa.setSetting("adaptivestream.res.secure.max", "720p")
    elif _r == 2:
        _self.setSetting("isa_prompt", "false")
    else:
        return