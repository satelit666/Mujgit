# -*- coding: utf-8 -*-
# Author: cache-sk
# Created on: 20.8.2019
import sys
import urllib
from collections.abc import Mapping

import inputstreamhelper
import xbmcaddon
import xbmcgui
import xbmcplugin
import json
import logger
import copy
import ast


import utils
from skylink import StreamNotResolvedException

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_python3 = sys.version_info[0] >= 3

TYPES = [
    {
        "msg": "Canal+",
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "cpactioncz", "index": 0},
    },
    {
        "msg": "Filmbox+",
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "filmboxcz2", "index": 0},
    },
    {
        "msg": "Edisonline",
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "m7fvfecz", "index": 0},
    },
    {
        "msg": _addon.getLocalizedString(30813),
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "_kids", "index": 0},
    },
    {
        "msg": _addon.getLocalizedString(30808),
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "_genre", "index": 0},
    },
    {
        "msg": "Watchlist",
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "_watchlist", "index": 0},
    },
    {
        "msg": _addon.getLocalizedString(30005),
        "code": "movies",
        "isMovie": True,
        "data": {"owner": "_search", "index": 0},
    },
    
]
CATEGORIES = [
    {"msg": _addon.getLocalizedString(30810), "code": "Action", "pin": False},
    {"msg": _addon.getLocalizedString(30811), "code": "Comedy", "pin": False},
    {"msg": _addon.getLocalizedString(30812), "code": "Family", "pin": False},
    {"msg": _addon.getLocalizedString(30813), "code": "Kids", "pin": False},
    {"msg": _addon.getLocalizedString(30814), "code": "Science Fiction", "pin": False},
    {"msg": _addon.getLocalizedString(30815), "code": "Fantasy", "pin": False},
    {"msg": _addon.getLocalizedString(30816), "code": "Adventure", "pin": False},
    {"msg": _addon.getLocalizedString(30817), "code": "Crime", "pin": False},
    {"msg": _addon.getLocalizedString(30818), "code": "Drama", "pin": False},
    {"msg": _addon.getLocalizedString(30819), "code": "Romance", "pin": False},
    {"msg": _addon.getLocalizedString(30820), "code": "Thriller", "pin": False},
    {"msg": _addon.getLocalizedString(30821), "code": "Horror", "pin": False},
    {"msg": _addon.getLocalizedString(30822), "code": "Documentary", "pin": False},
    {"msg": _addon.getLocalizedString(30823), "code": "Biography", "pin": False},
    {"msg": _addon.getLocalizedString(30824), "code": "History", "pin": False},
    {"msg": _addon.getLocalizedString(30825), "code": "Music", "pin": False},
    {"msg": _addon.getLocalizedString(30826), "code": "Sport", "pin": False},
    {"msg": _addon.getLocalizedString(30829), "code": "Culture", "pin": False},
    {"msg": _addon.getLocalizedString(30830), "code": "People", "pin": False},
    {"msg": _addon.getLocalizedString(30831), "code": "Natural History", "pin": False},
    {"msg": _addon.getLocalizedString(30832), "code": "Science", "pin": False},
    {"msg": _addon.getLocalizedString(30833), "code": "Cars & Motors", "pin": False},
    {"msg": _addon.getLocalizedString(30834), "code": "Technology", "pin": False},
    {"msg": _addon.getLocalizedString(30827), "code": "Other", "pin": False},
    {"msg": _addon.getLocalizedString(30828), "code": "Erotic", "pin": True},
    {"msg": _addon.getLocalizedString(30851), "code": "playlist-bookmarks-vod", "pin": False},
    {"msg": _addon.getLocalizedString(30852), "code": "playlist-bookmarks-epg", "pin": False},
    {"msg": _addon.getLocalizedString(30853), "code": "playlist-reminders", "pin": False},
]

def get_url(**kwargs):
    return "{0}?{1}".format(_url, utils.urlencode(kwargs))


def types():
    xbmcplugin.setPluginCategory(_handle, _addon.getLocalizedString(30800))
    for tp in TYPES:
        list_item = xbmcgui.ListItem(label=tp["msg"])
        list_item.setInfo("video", {"title": tp["msg"]})
        if tp["data"]["owner"]=="_search":
            list_item.setArt({"icon": "DefaultAddonsSearch.png"})
            link = get_url(library="search", ctype=tp["data"])
        else:
            if tp["data"]["owner"]=="_watchlist":
                list_item.setArt({"icon": "DefaultPlaylist.png"})
            link = get_url(library="category", ctype=tp["data"])
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, link, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)


def categories(sl, ctype):
    title = _addon.getLocalizedString(30800)
    mainArray = "collection"
    catKey = "key"
    
    endpoint = "/collections/videos,owner," + ctype["owner"]
    params = {"group": "allandgenre", "sort": "licensestart,desc"}
    if(ctype["owner"]=="_genre"):
        endpoint = "/collections/movies"
        params = {"group": "genre", "sort": "newest"}
    if(ctype["owner"]=="_kids"):
        endpoint = "/discovery/Genre_Canal_Kids"
        params = {}
        mainArray = "rows"
        catKey = "title"
    if(ctype["owner"]=="_watchlist"):
        endpoint = "/library/code_playlist"
        params = {}
        mainArray = "library"
    items = utils.call(sl, lambda: sl.library(endpoint, params))
    
    for tp in TYPES:
        if tp["data"]["owner"] == ctype["owner"]:
            title += " / " + tp["msg"]
            break
    xbmcplugin.setPluginCategory(_handle, title)

    for cat in items[mainArray]:
        if(cat[catKey]=="playlist-adult" and ctype["owner"]=="_watchlist"):
            continue
        cat_name = next((c["msg"] for c in CATEGORIES if c["code"] == cat[catKey]),cat[catKey])
        #cat_name = next((c["msg"] for c in WATCHLIST_CAT if c["code"] == cat[catKey]),cat[catKey])

        list_item = xbmcgui.ListItem(label=cat_name)
        list_item.setInfo("video", {"title": cat_name})
        list_item.setArt({"icon": "DefaultGenre.png"})
        link = get_url(library="list", ctype=ctype, category=cat["query"])
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, link, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)


def search(sl, ctype):
    title = "search"
    dialog = xbmcgui.Dialog()
    query = dialog.input("Zadajte hľadaný výraz")
    if not query:
        xbmcplugin.endOfDirectory(_handle, succeeded=False)
        return
    endpoint = "/search"
    params = {"query": query}


    items = utils.call(sl, lambda: sl.library(endpoint, params))
    xbmcplugin.setPluginCategory(_handle, title)
    xbmcplugin.setContent(_handle, "movies")

    for cat in items["collection"]:
        if cat["label"]=="sg.ui.search.epg":
            continue
        for item in cat["assets"]:
            
            
            duration = int(item["params"]["duration"]) if "duration" in item["params"] else None
            itemTitle = "[B][S" + str(item["params"]["seriesSeason"]) + ("E" + str(item["params"]["seriesEpisode"]) + "][/B], " if "seriesEpisode" in item["params"] else "") if "seriesSeason" in item["params"] else ""
            list_item = xbmcgui.ListItem(label=itemTitle + item["title"])
            if "genres" in item["params"]:
                genres = [g.get("title") for g in item.get("params", {}).get("genres", []) if g.get("title")]
            else:
                genres=[]
            list_item.setInfo(
                "video",
                {
                  "title": itemTitle + item["title"],
                  "duration": duration,
                  "plot": item["desc"] if "desc" in item else "",
                  "genre" : genres,
                },
            
            )
            list_item.setArt({
                "icon": item["images"][0]["url"] + "&w=256&h=384",
                "poster": item["images"][0]["url"] + "&w=256&h=384",
                "fanart": item["images"][1]["url"] + "&w=1824&h=1026",
            })
            list_item.setProperty("IsPlayable", "true")
            link = get_url(library="play", lid=item["id"])
            is_folder = False
            xbmcplugin.addDirectoryItem(_handle, link, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)

def listOfItems(sl, ctype, category):
    title = _addon.getLocalizedString(30800)
    ctp = None
        
    for tp in TYPES:
        if tp["data"]["owner"] == ctype["owner"]:
            ctp = tp
            title += " / " + tp["msg"] #+ " / " + str(ctype["index"])
            break
    cat = None
    cat = category
    xbmcplugin.setPluginCategory(_handle, title)
    xbmcplugin.setContent(_handle, "movies")

    if ctp is None or cat is None:
        xbmcgui.Dialog().ok(
            heading=_addon.getLocalizedString(30800),
            line1=_addon.getLocalizedString(30806),
        )
        xbmcplugin.endOfDirectory(_handle)
        return
        
    endpoint = "/assets"
    params = {"query": cat, "limit": 22, "from": ctype["index"]}
    params["sort"] = "licensestart,desc" if ctype["owner"]!="_kids" else None
    if ctype["owner"]=="_watchlist":
        params = {"query": cat, "limit": 100,"sort": "default"}
    
    items = utils.call(sl, lambda: sl.library(endpoint, params))
    
    for item in items["assets"]:
        type = "[" + _addon.getLocalizedString(30801) + "]" if (item["type"]=="VOD" or item["type"]=="EPG") else "[" + _addon.getLocalizedString(30802) + "]"
        list_item = xbmcgui.ListItem(label=item["title"])
        if "genres" in item["params"]:
            genres = [g.get("title") for g in item.get("params", {}).get("genres", []) if g.get("title")]
        else:
            genres=[]
        list_item.setInfo(
            "video",
            {
                "title": item["title"] + " [B]" + type + "[/B]",
                "plot": item["description"] if "description" in item else "",
                "duration": int(item["params"]["duration"]) if "duration" in item["params"] else "",
                "genre" : genres,
            },
        )
        list_item.setArt({
            "icon": item["images"][0]["url"] + "&w=256&h=384",
            "poster": item["images"][0]["url"] + "&w=256&h=384",
            "fanart": item["images"][1]["url"] + "&w=1824&h=1026",
        })
        
        if item["type"] == "EPGSeries":
          link = get_url(
            library="episodes", lid=item["id"], sz=1, title=ctype["owner"]
          )
        elif item["type"] == "EPG":
          link = get_url(
            library="play", lid=item["id"], sz=1, title=ctype["owner"]
          )
        else:
          link = get_url(
            library="play" if item["type"]=="VOD" else "seasons", lid=item["id"], ctype=ctype
          )
        is_folder = item["type"]=="VODSeries" or item["type"]=="EPGSeries"
        if item["type"]=="VOD" or item["type"]=="EPG":
            list_item.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(_handle, link, list_item, is_folder)

    list_item = xbmcgui.ListItem(label="item")
    ctype["index"] += 22
    list_item.setInfo("video",{"title": "[B]-->[/B]",})
    link = get_url(library="list", ctype=ctype, category=cat)    
    xbmcplugin.addDirectoryItem(_handle, link, list_item, True)
    
    #xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_handle)


def seasons(sl, lid):
    copyOfSelf = copy.deepcopy(sl)              # Hacky workaround to allow sending two requests, since loginWithSavedSession overwrites the required object.
    endpoint =  "/assets/" + lid
    params = {}
    data = utils.call(sl, lambda: sl.library(endpoint, params))
    xbmcplugin.setPluginCategory(_handle, data["title"])
    xbmcplugin.setContent(_handle, "tvshows")
    
    sl = copy.deepcopy(copyOfSelf)
    endpoint =  "/collections/episodes"
    params = {"group": "default", "sort": "default", "asset": lid}
    seasons = utils.call(sl, lambda: sl.library(endpoint, params))

    for season in seasons["collection"]:
        sz = season["title"]
        title = _addon.getLocalizedString(30807) + " " + sz
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo("video", {"title": title})
        #list_item.setArt({"thumb": data["poster"]})
        link = get_url(library="episodes", lid=lid, sz=sz, title=data["title"])
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, link, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle)


def episodes(sl, lid, sz, title):
    endpoint =  "/assets"
    if title != "_kids":
      params =  {"query": "episodes," + lid + ",season," + sz, "sort": "seasonepisode"}
    else:
        params =  {"query": "replayepisodes," + lid, "sort": "default"}
    data = utils.call(sl, lambda: sl.library(endpoint, params))
    xbmcplugin.setPluginCategory(
        _handle, title + " / " + _addon.getLocalizedString(30807) + " " + sz
    )
    xbmcplugin.setContent(_handle, "episodes")

    for episode in data["assets"]:
        list_item = xbmcgui.ListItem(label=episode["title"])
        duration = int(episode["params"]["duration"]) if "duration" in episode["params"] else None
        epTitle = "[B][S" + str(episode["params"]["seriesSeason"]) + ("E" + str(episode["params"]["seriesEpisode"]) + "][/B], " if "seriesEpisode" in episode["params"] else "") if "seriesSeason" in episode["params"] else ""
        list_item.setInfo(
            "video",
            {
              "title": epTitle + episode["title"],
              "duration": duration,
              "plot": episode["desc"] if "desc" in episode else "",
            },
            
        )
        list_item.setArt({
            "icon": episode["images"][0]["url"] + "&w=256&h=384",
            "poster": episode["images"][0]["url"] + "&w=256&h=384",
            "fanart": episode["images"][1]["url"] + "&w=1824&h=1026",
        })
        list_item.setProperty("IsPlayable", "true")
        link = get_url(library="play", lid=episode["id"])
        is_folder = False
        xbmcplugin.addDirectoryItem(_handle, link, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle)


def play(sl, lid):
    copyOfSelf = copy.deepcopy(sl)
    endpoint =  "/assets/" + lid
    params = {}
    data = utils.call(sl, lambda: sl.library(endpoint, params))
    
    if "desc" in data:
        params = {}
        if "deals" in data and data["deals"] and "name" in data["deals"][0]:
            params.update({"dn": data["deals"][0]["name"]})
        try:
            sl = copy.deepcopy(copyOfSelf)
            info = utils.call(sl, lambda: sl.channel_info(lid))
        except StreamNotResolvedException as e:
            xbmcgui.Dialog().ok(data["title"], _addon.getLocalizedString(30805))
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        if info:
            is_helper = inputstreamhelper.Helper(info["protocol"], info["drm"])
            if is_helper.check_inputstream():
                playitem = xbmcgui.ListItem(path=info["path"])
                if _python3:  # Python 3.x
                    playitem.setProperty("inputstream", is_helper.inputstream_addon)
                else:  # Python 2.5+
                    playitem.setProperty(
                        "inputstreamaddon", is_helper.inputstream_addon
                    )
                playitem.setProperty(
                    "inputstream.adaptive.manifest_type", info["protocol"]
                )
                playitem.setProperty("inputstream.adaptive.license_type", info["drm"])
                playitem.setProperty("inputstream.adaptive.license_key", info["key"])
                try:
                    playitem.setProperty('inputstream.adaptive.stream_headers', info["path"].split("|")[1])
                    playitem.setProperty('inputstream.adaptive.manifest_headers', info["path"].split("|")[1])
                except:
                    pass

                #if "subs" in data:
                #    params = {"z": "subtitle", "lng": sl._lang, "id": lid}
                #    subs = utils.call(sl, lambda: sl.library(params))
                #    if "url" in subs:
                #        playitem.setSubtitles([subs["url"]])
                video_info = {}

                if "title" in data:
                    video_info.update({"title": data["title"]})

                if "desc" in data:
                    video_info.update({"plot": data["desc"]})

                if "credits" in data["params"] and len(data["params"]["credits"])>0:
                    video_info.update({"director": data["params"]["credits"][0]["person"]})

                playitem.setInfo("video", video_info)

                if "credits" in data["params"]:
                    playitem.setCast([{"name": a["person"]} for a in data["params"]["credits"]])

                if "images" in data:
                    playitem.setArt({"thumb": data["images"][1]["url"]+"&w=1824&h=1026"})

                xbmcplugin.setResolvedUrl(_handle, True, playitem)
            return
        #xbmcgui.Dialog().ok(
        #    heading=data["title"], line1=_addon.getLocalizedString(30805)
        #)
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())


def router(args, sl):
    if args:
        if args["library"][0] == "category":
            categories(sl, ast.literal_eval(args["ctype"][0]))
        elif args["library"][0] == "search":
            search(sl, ast.literal_eval(args["ctype"][0]))
        elif args["library"][0] == "list":
            listOfItems(sl, ast.literal_eval(args["ctype"][0]), args["category"][0])
        elif args["library"][0] == "seasons":
            seasons(sl, args["lid"][0])
        elif args["library"][0] == "episodes":
            episodes(sl, args["lid"][0], args["sz"][0], args["title"][0])
        elif args["library"][0] == "play":
            play(sl, args["lid"][0])
        else:
            types()
    else:
        types()
