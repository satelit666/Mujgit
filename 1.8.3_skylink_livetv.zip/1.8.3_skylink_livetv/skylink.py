import binascii
import datetime
import json
import os
import time
import uuid
import os
import json
import uuid
import time
import base64
import hashlib
import hmac
from datetime import datetime, timedelta, timezone
import requests
import requests.cookies
import logger
from urllib.parse import quote
import xbmcgui
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor, as_completed
import re
import xbmcvfs
from io import StringIO




try:
    from urlparse import parse_qs, unquote, urlparse  # 3.x
except ImportError:
    from urllib.parse import parse_qs, unquote, urlparse  # 2.7

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"
M7_DOMAIN = "m7cz.solocoo.tv"
M7_API_WEB = "https://" + M7_DOMAIN + "/"
M7_API_URL = M7_API_WEB + "m7cziphone/"

ADDON = xbmcaddon.Addon()
REUSE_LAST_DEVICE = ADDON.getSettingBool("reuse_last_device")


class SkylinkException(Exception):
    def __init__(self, id):
        self.id = id


class UserNotDefinedException(SkylinkException):
    def __init__(self):
        self.id = 30501


class UserInvalidException(SkylinkException):
    def __init__(self):
        self.id = 30502


class TooManyDevicesException(SkylinkException):
    def __init__(self, data):
        self.id = 30505
        self.devices = data["devices"]


class StreamNotResolvedException(SkylinkException):
    def __init__(self, detail={}):
        self.id = 30510
        self.detail = detail




class SkylinkSessionData:      #Modified for SSO method
    
    uid = ""
    secret = ""
    id = ""
    userName = ""
    userLogin = ""
    userId = ""
    token = ""
    communityName = ""
    brandName = ""
    ssoToken = ""
    language = ""
    consent = ""
    countryCode = ""
    subscriberId = ""
    deviceSerial = ""

    def __init__(self, **entries):
        self.__dict__.update(entries)

    def __getitem__(self, key):
        return self.__dict__[key]

    def __contains__(self, key):
        return key in self.__dict__

    def is_valid(self):
        return bool(self.__dict__.get("token")) and bool(self.__dict__.get("deviceSerial"))

    def clear(self):
        self.__dict__.clear()
        
  #  def is_valid(self):        #Modified for SSO method
  #      return (self.ssoToken != "") and (self.token != "")

  #  def clear(self):      #Modified for SSO method
  #      userName = ""
  #      userLogin = ""
  #      userId = ""
  #      token = ""
  #      communityName = ""
  #      brandName = ""
  #      ssoToken = ""
  #      language = ""
  #      consent = ""
  #      countryCode = ""
  #      subscriberId = ""
  #      deviceSerial = ""


class Skylink:      #Modified for SSO method
    _username = ""
    _password = ""
    _storage_path = ""
    _storage_file = ""
    _session = requests.Session()
    _session.max_redirects = 3
    _data = SkylinkSessionData()
    _url = ""
    _api_url = ""
    _show_pin_protected = True
    _pin_protection = False
    
    SECRET_KEY = 'OXh0-pIwu3gEXz1UiJtqLPscZQot3a0q'
    BASE_URL = 'https://livetv.skylink.sk/'
    API_BASE = 'https://tvapi.solocoo.tv/v1'
    LOGIN_BASE = 'https://m7.login.solocoo.tv'
    APP_VERSION = ''
    CLIENT_KEY = ''
    DEVICE_SERIAL = ''
    COUNTRY = ""
    BRAND = ""

    def __init__(      #Modified for SSO method
        self,
        username,
        password,
        storage_dir,
        provider="directone.hu",        # old method using it not needed
        show_pin_protected=True,
    ):
        self._provider = provider
        self._lang = "hu"               # old method using it not needed
        self._app = "upchu"             # old method using it not needed
        self._usermane = username
        self._password = password
        self.USERNAME = username
        self.PASSWORD = password
        self._storage_path = storage_dir
        self._storage_file = os.path.join(
            self._storage_path, "%s.session" % username.lower()
        )
        playlist_folder = xbmcvfs.translatePath(ADDON.getSetting("playlist_folder"))
        if not playlist_folder:
            playlist_folder = self._storage_path
        self._logos_path = os.path.join(playlist_folder, "Channel_logos")
        os.makedirs(self._logos_path, exist_ok=True)
        
        self.device_friendly_name = ADDON.getSetting("device_friendly_name")
        self._show_pin_protected = show_pin_protected
        self._pin_protection = "false" != ADDON.getSetting(
            "pin_protection"
        )
        
        self.SECRET_KEY = 'OXh0-pIwu3gEXz1UiJtqLPscZQot3a0q'
        self.BASE_URL = 'https://livetv.skylink.sk/'
        self.API_BASE = 'https://tvapi.solocoo.tv/v1'
        self.LOGIN_BASE = 'https://m7.login.solocoo.tv'
        self.DEVICE_SERIAL = ''
        self.CLIENT_KEY = '' 
        self.APP_VERSION = ''
        self.UNIX_TIMESTAMP = ""       
        operator_choice = int(ADDON.getSetting("operator_region"))  # returns 0, 1, or 2   --- 0: HU, 1: SK, 2: CZ
        if operator_choice == 0:
            BASE_URL = self.BASE_URL = 'https://play.canalplus.hu/'
            self.COUNTRY = 'HU'
            self.BRAND = 'upchu'
        elif operator_choice == 1:
            BASE_URL = self.BASE_URL = 'https://livetv.skylink.sk/'
            self.COUNTRY = 'SK'
            self.BRAND = 'slsk'
        elif operator_choice == 2:
            BASE_URL = self.BASE_URL = 'https://livetv.skylink.cz/'
            self.COUNTRY = 'CZ'
            self.BRAND = 'slcz'
        self._get_build_txt()
        self._load_session()
            

    def _json_body(self, data):       #New function for SSO method
        return json.dumps(data, separators=(',', ':'), sort_keys=False)
        
    def _base64_url(self, data):        #New function for SSO method
        return base64.b64encode(data).decode().replace('+', '-').replace('/', '_').rstrip('=')

    def _sha256(self, data):        #New function for SSO method
        return hashlib.sha256(json.dumps(data, separators=(',', ':')).encode()).digest()

    def _hmac_sha256(self, data):        #New function for SSO method
        return hmac.new(base64.urlsafe_b64decode(self.SECRET_KEY + '=='), data.encode(), hashlib.sha256).digest()

    def _sign_request(self, url, payload):       #New function for SSO method
        self.UNIX_TIMESTAMP = str(int(time.time()))
        hashed = self._base64_url(self._sha256(payload))
        raw = f"{url}{hashed}{self.UNIX_TIMESTAMP}"
        return self._base64_url(self._hmac_sha256(raw))

    def _make_headers(self, extra=None):       #New function for SSO method
        base = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'en-GB,en;q=0.9',
            'Cache-Control': 'no-cache',
            'Content-Type': 'application/json',
            'Origin': self.BASE_URL,
            'Pragma': 'no-cache',
            'Priority': 'u=1, i',
            'Referer': self.BASE_URL + '/',
            'Sec-Ch-Ua': '"Not A(Brand";v="8", "Chromium";v="135", "Google Chrome";v="135"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': 'Windows',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
        }
        if extra:
            base.update(extra)
        return base
        
    def _get_device_info(self, serial):       #New function for SSO method
        return {
            'osVersion': 'Windows 10',
            'deviceModel': 'Chrome',
            'deviceType': 'PC',
            'deviceSerial': serial,
            'deviceOem': 'Chrome',
            'devicePrettyName': self.device_friendly_name,
            'appVersion': self.APP_VERSION,
            'language': 'en_US',
            'brand': self.BRAND
        }

    def _store_session(self):           #old function but used also for SSO method
        if not os.path.exists(self._storage_path):
            os.makedirs(self._storage_path)
        with open(self._storage_file, "w") as f:
            json.dump(self._data, f)

    def _load_session(self):            #old function but used also for SSO method
        logger.log.info(self._storage_file)
        if os.path.exists(self._storage_file):
            with open(self._storage_file, "r") as f:
                self._data = SkylinkSessionData(**json.load(f))
                #self._data.__dict__ = json.load(f)     # Object
                #self._data = json.load(f)              # Dict
                
    def _get_build_txt(self):       #New function for SSO method
        r = requests.get(self.BASE_URL + "/build.txt")
        text = r.text
        self.CLIENT_KEY = text.split("<clientAuthKey>")[1].split("</clientAuthKey>")[0].strip()
        self.APP_VERSION = text.split("<branch>")[1].split("</branch>")[0].strip().split("-")[0]

    def _provision(self, device_info):       #New function for SSO method
        payload = {**device_info, 'featureLevel': 6}
        r = requests.post(f"{self.API_BASE}/provision", headers=self._make_headers(), data=self._json_body(payload))
        #return r.json().get("session", {}).get("provisionData") if r.status_code == 200 else raise SkylinkException(30900)  
        if r.status_code == 200:
            return r.json().get("session", {}).get("provisionData")
        else:
            raise SkylinkException(30900)      # Exception "Provision failed"

    def _demo(self, provision_data, device_info):       #New function for SSO method
        url = f"{self.LOGIN_BASE}/demo"
        payload = {"provisionData": provision_data, "deviceInfo": {**device_info, "country": self.COUNTRY}}
        sig = self._sign_request(url, payload)
        headers = self._make_headers({"Authorization": f"Client key={self.CLIENT_KEY},time={self.UNIX_TIMESTAMP},sig={sig}"})
        r = requests.post(url, headers=headers, data=self._json_body(payload))
        return r.json()["ssoToken"]

    def _session(self, sso_token, provision_data, device_info):     #New function for SSO method
        payload = {
                "ssoToken": sso_token, **device_info, "memberId": "0", "featureLevel": 6, "provisionData": provision_data
            }
        r = requests.post(f"{self.API_BASE}/session", headers=self._make_headers(), data=self._json_body(payload))
        #  SUCCESS
        if r.status_code == 200 and "token" in r.json():
            session_data = r.json()
            session_data["deviceSerial"] = device_info["deviceSerial"]
            return session_data
        
        #  TOO MANY DEVICES
        if r.status_code == 409:
            data = r.json()
            if data.get("label") == "sg.ui.error.register.too_many_devices":
                new_sso = data.get("ssoToken")
                devices = data.get("solution", {}).get("deviceList", {}).get("devices", [])

                if not REUSE_LAST_DEVICE:
                    xbmcgui.Dialog().ok("Device Limit Reached", "Too many devices are registered.\nPlease remove one with browser in your account settings, then restart Kodi.")
                    raise SkylinkException(30904)  # Exception: TooManyDevicesNoReuseLastDevice Manual cleanup required

                if devices:
                    device_options = [
                        f"{d.get('desc', 'Unknown')} ("
                        f"{datetime.strptime(d['lastActivity'].rstrip('Z')[:26], '%Y-%m-%dT%H:%M:%S.%f').strftime('%Y-%m-%d %H:%M') if 'lastActivity' in d else 'N/A'})"
                        for d in devices
                    ]
                    selection = xbmcgui.Dialog().select("Select device to remove", device_options)
                    if selection == -1:
                        xbmcgui.Dialog().ok("Cancelled", "No device selected or cancelled. No device has been removed, cannot proceed.")
                        raise SkylinkException(30905) # Exception: DeviceNotSelectedCancelled Cancelled or no device selected

                    to_remove = devices[selection]["deviceId"]

                    #  Retry session with 'removeDevice'
                    payload["ssoToken"] = new_sso
                    payload["removeDevice"] = to_remove
                    r2 = requests.post(f"{self.API_BASE}/session", headers=self._make_headers(), data=self._json_body(payload))
                    if r2.status_code == 200 and "token" in r2.json():
                        session_data = r2.json()
                        session_data["deviceSerial"] = device_info["deviceSerial"]
                        return session_data
                    else:
                        xbmcgui.Dialog().ok("Device Removal Failed", "Could not register even after device removal.")
                        raise SkylinkException(30906)   # Exception: DeviceRemovalFailed Cant register after removal
        #  All else failed
        try:
            msg = r.json().get("Message", "Unknown error")
        except Exception:
            msg = r.text
        xbmcgui.Dialog().ok("Register device Failed", msg)
        raise SkylinkException(30907)       # Exception: DeviceRegistrationFailed unknown error

    def _signin(self, provision_data, old_token, device_info):       #New function for SSO method
        url = f"{self.LOGIN_BASE}/login"
        payload = {
            "provisionData": provision_data,
            "deviceInfo": {**device_info, 'country': self.COUNTRY},
            "oldSsoToken": old_token
        }
        sig = self._sign_request(url, payload)
        r = requests.post(url, headers=self._make_headers({'Authorization': f'Client key={self.CLIENT_KEY},time={self.UNIX_TIMESTAMP},sig={sig}'}), data=self._json_body(payload))
        #return r.json().get("ticket") if r.status_code == 200 else raise SkylinkException(30901)  # Exception: "Signin failed"
        if r.status_code == 200:
            return r.json().get("ticket")
        else:
            raise SkylinkException(30901)  # Exception: "Signin failed"

    def _loginWithTicket(self, ticket):       #New function for SSO method
        url = f"{self.LOGIN_BASE}/login"
        payload = {"ticket": ticket, "userInput": {"username": self.USERNAME, "password": self.PASSWORD}}
        sig = self._sign_request(url, payload)
        r = requests.post(url, headers=self._make_headers({'Authorization': f'Client key={self.CLIENT_KEY},time={self.UNIX_TIMESTAMP},sig={sig}'}), data=self._json_body(payload))
        #return r.json().get("ssoToken") if r.status_code == 200 else raise SkylinkException(30902)  # Exception: "LoginWithTicket failed"
        if r.status_code == 200:
            return r.json().get("ssoToken")
        else:
            raise SkylinkException(30902)  # Exception: "LoginWithTicket failed"

    def _getEntitlements(self):     #New function for SSO method
        Bearer = self._data["token"]
        headers = self._make_headers({'Authorization': f'Bearer {Bearer}'})
        r = requests.get(self.API_BASE + "/entitlements", headers=headers)
        if r.status_code != 200:
            raise SkylinkException(30903) # Exception: getEntitlements failed
        json_data = r.json()
        entitlements_list = json_data.get("offers", [])
        entitlements = []
        for d in entitlements_list:
            entitlements.append(d.get("id"))
        return entitlements

    def _registerDevice(self):       #New function for SSO method
        if self.DEVICE_SERIAL == '':
            self.DEVICE_SERIAL = 'w' + str(uuid.uuid4())
        device_info = self._get_device_info(self.DEVICE_SERIAL)
        provision_data = self._provision(device_info)
        demo_token = self._demo(provision_data, device_info)
        session_data = self._session(demo_token, provision_data, device_info)
        signin_ticket = self._signin(provision_data, session_data["ssoToken"], device_info)
        login_token = self._loginWithTicket(signin_ticket)
        self._data = self._session(login_token, provision_data, device_info)
        self._store_session()

    def _auth(self, device):       #Modified for SSO method
        if self._data.is_valid():
            return

        try:
            if (self._usermane == "") or (self._password == ""):
                raise UserNotDefinedException

            self._registerDevice()
            self._store_session()
        except:
            self._data.clear()
            self._store_session()
            raise

    def loginWithSavedSession(self, saved_session):       #New function for SSO method
        #self.DEVICE_SERIAL = self._data.deviceSerial
        self.DEVICE_SERIAL = self._data["deviceSerial"]
        #print(self.DEVICE_SERIAL)
        device_info = self._get_device_info(self.DEVICE_SERIAL)
        provision_data = self._provision(device_info)
        try:
            # Try to resume session with saved token
            self._data = self._session(saved_session.ssoToken, provision_data, device_info)
            self._store_session()
        except SkylinkException as e:
            # If session() exited due to failure, fall back to re-register
            logger.log.info("Saved session failed. Re-registering device...")
            xbmcgui.Dialog().notification("Saved session failed", "Re-registering device...", xbmcgui.NOTIFICATION_INFO, 3000)
            self._registerDevice()
            self._store_session()
            logger.log.info("session saved")

    def _login(self):          #Modified for SSO method 
        if self._data.is_valid(): # ISSUE HERE no session but this gives true
            self.loginWithSavedSession(self._data) 
            return
        #self._auth("")
        self._registerDevice()
        #self._login()

    def reconnect(self, device):        #NOld function but still used for SSO method
        self._data.clear()
        self._auth(device)

    @staticmethod
    def _time():           #Old function not used for SSO
        return int(time.time() * 1000)

    def _request(self, method, url, **kwargs):      #Old function not used for SSO
        return self._session.request(method, url, **kwargs)

    def _get (self, url, params):                   # NEW - used by library API
        Bearer = self._data["token"]
        #logger.log.info(f"[spejlo] {json.dumps(url)} - {json.dumps(params)}")
        headers = self._make_headers({'Authorization': f'Bearer {Bearer}'})
        r = requests.get(self.API_BASE + url, headers=headers,params=params)
        if r.status_code != 403 and url=="pin/parental/verify":
            return 403
        if r.status_code != 200:
            #logger.log.info(f"[spejlo] {r.status_code}")
            raise SkylinkException(30903) # Exception: _get failed
        
        return r
        
    def _post (self, url, params):                   # NEW - used by library API
        Bearer = self._data["token"]
        headers = self._make_headers({'Authorization': f'Bearer {Bearer}'})
        r = requests.post(self.API_BASE + url, headers=headers,json=params)
        if r.status_code == 403 and url=="/pin/parental/verify":
            return 403
        if r.status_code == 200 and url=="/pin/parental/verify":
            return 200
        if r.status_code != 200:
            raise SkylinkException(30903) # Exception: _post failed
        
        return r


    def _download_logo(self, url, channel_name):
        if not url or not channel_name:
            return None

        # Clean the channel name for filename (remove invalid filesystem characters)
        safe_name = re.sub(r'[^\w\-_. ]', '_', channel_name.strip())
        filename = f"{safe_name}.png"

        logo_path = os.path.join(self._logos_path, filename)

        if not os.path.exists(logo_path):
            try:
                r = requests.get(url, timeout=10)
                if r.status_code == 200:
                    with open(logo_path, "wb") as f:
                        f.write(r.content)
                    logger.log.info(f"[Skylink] Logo downloaded: {filename}")
                else:
                    logger.log.info(f"[Skylink] Logo download failed (status {r.status_code}): {url}")
            except Exception as e:
                logger.log.info(f"[Skylink] Exception while downloading logo for {channel_name}: {e}")
                return None
        return logo_path
    
    def channels(self):        #Modified for SSO method
        """Returns available live channels, when reply is set returns replayable channels as well
        :param replay: bool
        :return: Channels data
        """
        self._login()
        entitlements = self._getEntitlements()
        Bearer = self._data["token"]
        headers = {
            'Authorization': f'Bearer {Bearer}',
            'Accept-Encoding': 'gzip',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
        }
        
        with requests.Session() as session:
            session.headers.update(headers)
            url = f"{self.API_BASE}/bouquet"
            r = session.get(url)
            if r.status_code != 200:
                print("Failed to get channel list")
                return []
            raw_channels = r.json().get("channels", [])
            simplified_channels = []
            for ch in raw_channels:
                info = ch.get("assetInfo", {})
                deals = info.get("deals", [])
                # === Skip if no offers or no match with entitlements ===
                if not deals or not any(offer in entitlements for deal in deals for offer in deal.get("offers", [])):
                    continue
                channel_id = info.get("id")
                title = info.get("title")
                images = info.get("images", [])
                lcn = info.get("params", {}).get("lcn", 9999)  # default high LCN if missing
                replay = info.get("params", {}).get("replay", False)
                # Get logo ending in _w56.png
                #icon_url = next((img["url"] for img in images if img.get("url", "").endswith("_w56.png")), None)
                icon_url = next((img["url"] for img in images if img.get("type") == "cl" and img.get("url", "").endswith("_m.png")),None)
                local_logo_path = self._download_logo(icon_url, title)
                # Defaults
                pin_protected = False
                replay_seconds = None
                replay_days = None

                # ========== Extra channel info via /assets/{channel_id} ==========
                asset_url = f"https://tvapi.solocoo.tv/v1/assets/{channel_id}"
                r2 = session.get(asset_url)
                if r2.status_code == 200:
                    asset = r2.json()
                    pin_protected = asset["params"].get("pinProtected", False)

                    if replay:
                        replay_seconds = asset.get("params", {}).get("replayExpiry", 0)
                        replay_days = replay_seconds // 86400 if replay_seconds else 0

                # ========== Build simplified channel entry ==========
                if channel_id and title:
                    channel_entry = {
                        "id": channel_id,
                        "title": title,
                        "icon": icon_url,
                        "replay": replay,
                        "pinProtected": pin_protected,
                        "replayDays": replay_days if replay_days is not None else None,
                        "lcn": lcn  # keep for sorting
                    }
                    if not(not self._show_pin_protected and pin_protected):
                        simplified_channels.append(channel_entry)

            # Sort by LCN and remove from output
            simplified_channels.sort(key=lambda x: x["lcn"])
            for ch in simplified_channels:
                ch.pop("lcn", None)
        return simplified_channels

    def _headers_str(self, headers):    #New function for SSO method
        res = ""
        for key in headers:
            res = res + "&" + key + "=" + requests.utils.quote(headers[key])
        return res[1:]

    def fix_base64(self, cert):        #New for SSO method fixes license server certificate / Not needed for now
        cert = cert.replace('-', '+').replace('_', '/').strip()
        return cert + '=' * (-len(cert) % 4)

    def channel_info(self, channel_id):        #Modified for SSO method
        """Returns channel info
        :param channel_id: str
        :return: dict with stream info
        """

        self._login()
        Bearer = self._data["token"]
        headers = self._make_headers({'Authorization': f'Bearer {Bearer}'})
        url = f"{self.API_BASE}/assets/{channel_id}/play"

        payload = {
            "player": {
                "name": "RxPlayer",
                "version": "4.2.0",
                "capabilities": {
                    "mediaTypes": ["DASH"],
                    "drmSystems": ["Widevine"],
                    "audioQualities": ["Stereo"],
                    "smartLib": True,
                    "embeddedSubtitles": True
                }
            }
        }

        r = requests.post(url, headers=headers, json=payload)
        if r.status_code != 200:
            raise Exception("Stream request failed")

        result = r.json()

        stream_url = requests.utils.requote_uri(result["url"])
        license_url = result["drm"]["licenseUrl"]
        license_certificate = result["drm"]["cert"]

        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36"
        mpd_headers = {
            "User-Agent": user_agent,
            "Origin": self.BASE_URL,
            "Referer": self.BASE_URL + '/'
        }
        lic_headers = {
            "Content-Type": "application/octet-stream",
            "User-Agent": user_agent,
            "Origin": self.BASE_URL,
            "Referer": self.BASE_URL + '/'
        }        
        
        license_key = (license_url + "|" + self._headers_str(lic_headers) + "|R{SSM}|")
        stream_path = (stream_url + "|" + self._headers_str(mpd_headers))

        return {
            "protocol": "mpd",
            "path": stream_path,
            "drm": "com.widevine.alpha",
            #"certificate": self.fix_base64(license_certificate),
            "key": license_key
        }

    def epg(self, channels, from_date, to_date, showprogress=True, as_dict=False, EnrichedEPG=False):  # Modified for SSO method
        Bearer = self._data["token"]
        headers = {
            'Authorization': f'Bearer {Bearer}',
            'Accept-Encoding': 'gzip',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
        }
        EPG_FAST = ADDON.getSetting("epg_fast")
        #if EnrichedEPG==False: EnrichedEPG = True if EPG_FAST=="false" else False
        if showprogress==True: EnrichedEPG = True if EPG_FAST=="false" else False
        #EnrichedEPG = True  # Enable to use threading for enrichment, if false live.py loads faster but needed for replay.py handled with argument

        from_time = from_date.replace(hour=0, minute=0, second=0, microsecond=0) 
        until_time = to_date.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        
        from_time_str = from_time.strftime("%Y-%m-%dT%H:%M:%S.000Z").replace(":", "%3A")
        until_time_str = until_time.strftime("%Y-%m-%dT%H:%M:%S.000Z").replace(":", "%3A")

        #epg_lines = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '<tv>']
        epg_xml = StringIO()
        epg_xml.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        epg_xml.write('<tv>\n')
        
        epg_dict = {}  # Will hold structured data when as_dict=True
        metadata_cache = {}

        def fetch_metadata(session, program_id):
            try:
                meta_url = f"https://tvapi.solocoo.tv/v1/assets/{program_id}"
                r = session.get(meta_url)
                if r.status_code == 200:
                    return program_id, r.json()
            except Exception:
                pass
            return program_id, None
            
        with requests.Session() as session:
            session.headers.update(headers)
            if showprogress:
                dialog = xbmcgui.DialogProgressBG()
                dialog.create("please wait...", "Getting EPG")
                total_channels = len(channels)
                processed_channels = 0
            else:
                dialog = None

            # Add channels
            epg_cache = {}
            for ch in channels:
                ch_id = ch["id"]
                title = ch["title"]
                #epg_lines.append(f'  <channel id="{ch_id}">')
                #epg_lines.append(f'    <display-name>{title}</display-name>')
                #epg_lines.append('  </channel>')
                epg_xml.write(f'  <channel id="{ch_id}">\n')
                epg_xml.write(f'    <display-name>{title}</display-name>\n')
                epg_xml.write('  </channel>\n')
                url = f"https://tvapi.solocoo.tv/v1/schedule?channels={ch_id}&from={from_time_str}&until={until_time_str}"
                r = session.get(url)
                if r.status_code != 200:
                    epg_cache[ch_id] = -1;
                    continue
                epg_cache[ch_id] = r.json().get("epg", {}).get(ch_id, [])

            futures = {}
            if EnrichedEPG:
                with ThreadPoolExecutor(max_workers=5) as executor:
                    for ch in channels:
                        if showprogress:
                            processed_channels += 1
                            percent = int((processed_channels / total_channels) * 50)
                            dialog.update(percent)
                        ch_id = ch["id"]
                        #url = f"https://tvapi.solocoo.tv/v1/schedule?channels={ch_id}&from={from_time_str}&until={until_time_str}"
                        #r = session.get(url)
                        #if r.status_code != 200:
                        #    continue

                        #programmes = r.json().get("epg", {}).get(ch_id, [])
                        if epg_cache[ch_id] == -1:
                            continue
                        programmes = epg_cache[ch_id]
                        for prog in programmes:
                            catchup_id = prog.get("id")
                            if catchup_id:
                                futures[executor.submit(fetch_metadata, session, catchup_id)] = catchup_id
                    #for percentage
                    total_futures = len(futures)
                    completed = 0
                    
                    for future in as_completed(futures):
                        completed += 1
                        percent = int((completed / total_futures) * 100)
                        if showprogress:
                            percent = 50 + int((completed / total_futures) * 50)
                            dialog.update(percent)
                        prog_id, data = future.result()
                        metadata_cache[prog_id] = data

            # Add programmes
            for ch in channels:
                ch_id = ch["id"]
                #url = f"https://tvapi.solocoo.tv/v1/schedule?channels={ch_id}&from={from_time_str}&until={until_time_str}"
                #r = session.get(url)
                #if r.status_code != 200:
                #    continue

                #programmes = r.json().get("epg", {}).get(ch_id, [])
                if epg_cache[ch_id] == -1:
                    continue
                programmes = epg_cache[ch_id]
                for prog in programmes:
                    try:
                        start = datetime.fromisoformat(prog["params"]["start"].replace("Z", "+00:00")).strftime("%Y%m%d%H%M%S")
                        stop = datetime.fromisoformat(prog["params"]["end"].replace("Z", "+00:00")).strftime("%Y%m%d%H%M%S")
                        title_tag = prog.get("title", "N/A").replace("&", "&amp;")
                        icon_url = prog.get("images", [{}])[0].get("url", "") + "&w=305&h=171"
                        catchup_id = prog.get("id", "")
                        desc_tag = ""
                        category = "Unknown"
                        start_ts = int(datetime.fromisoformat(prog["params"]["start"].replace("Z", "+00:00")).timestamp())
                        stop_ts = int(datetime.fromisoformat(prog["params"]["end"].replace("Z", "+00:00")).timestamp())
                        duration = stop_ts - start_ts

                        if EnrichedEPG and catchup_id and metadata_cache.get(catchup_id):
                            meta = metadata_cache[catchup_id]
                            desc_tag = meta.get("desc", "").replace("&", "&amp;").strip() if meta.get("desc") else ""
                            genres = meta.get("params", {}).get("genres", [])
                            if genres and isinstance(genres, list):
                                category = genres[0].get("title", "Unknown")

                        genres = prog.get("params", {}).get("genres", [])
                        if genres and isinstance(genres, list):
                            category = genres[0].get("title", category)
                        format = prog.get("params", {}).get("formats", [])
                        if format and isinstance(format, list):
                            category = format[0].get("title", "Unknown") + ", " + category
                        
                        # If dict mode: populate structured epg
                        if as_dict:
                            epg_dict.setdefault(ch_id, []).append({
                                "start": start_ts,
                                "duration": duration,
                                "title": prog.get("title", "N/A"),
                                "catchup_id": catchup_id
                            })
                        
                        # Otherwise build XML
                        else:
                            #epg_lines.append(f'  <programme channel="{ch_id}" start="{start}" stop="{stop}" catchup-id="{catchup_id}">')
                            #epg_lines.append(f'    <title>{title_tag}</title>')
                            epg_xml.write(f'  <programme channel="{ch_id}" start="{start}" stop="{stop}" catchup-id="{catchup_id}">\n')
                            epg_xml.write(f'    <title>{title_tag}</title>\n')
                            def clean_cdata(text):
                                if not text:
                                    return ""
                                # Remove control characters
                                text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F]', '', text)
                                # Replace <<...>> with (...)
                                text = re.sub(r'<<([^<>]*)>>', r'(\1)', text)
                                # Replace stray << or >> with ( )
                                text = text.replace('<<', '(').replace('>>', ')')
                                # Remove isolated '<' or '>' that aren't part of tags
                                text = re.sub(r'(?<!<)<(?![a-zA-Z!/])', '', text)  # lone '<'
                                text = re.sub(r'(?<!>)>(?![a-zA-Z/])', '', text)    # lone '>'
                                # Escape ']]>' inside CDATA
                                text = text.replace(']]>', ']]]]><![CDATA[>')
                                return text
                            desc_cdata = clean_cdata(desc_tag)
                            #epg_lines.append(f'    <desc><![CDATA[{desc_cdata}]]></desc>')
                            epg_xml.write(f'    <desc><![CDATA[{desc_cdata}]]></desc>\n')
                            
                            if icon_url:
                                #epg_lines.append(f'    <icon src="{icon_url}"/>')
                                epg_xml.write(f'    <icon src="{icon_url}"/>\n')
                            #epg_lines.append(f'    <category>{category}</category>')
                            #epg_lines.append('  </programme>')
                            epg_xml.write(f'    <category>{category}</category>\n')
                            epg_xml.write('  </programme>\n')
                    except Exception as e:
                        print(f"[ERROR] Failed parsing program: {e}")

        #epg_lines.append('</tv>')
        epg_xml.write('</tv>\n')
        #result = "\n".join(epg_lines)
        result = epg_xml.getvalue()
        # show finished notification
        if showprogress:
            dialog.close()
            xbmcgui.Dialog().notification("EPG finished!", "EPG data is ready.", icon=xbmcgui.NOTIFICATION_INFO, time=2000)
        if as_dict:
            return epg_dict
        return result

    def replay_info(self, locId):        # NOT NEEDED AS CHANNELLINFO CAN DO THE SAME THING
        """Returns reply info
        :param locId:
        :return: Reply info
        """
        self._login()
        res = self._post(
            {
                "z": "replay",
                "lng": self._lang,
                "v": 1,
                "lid": locId,
                "d": 3,
                "u": self._data.uid,
            },
            json.dumps({"type": "dash", "flags": "1024"}).encode(),
        )

        stream = res.json()

        if not "url" in stream or not "drm" in stream:
            raise StreamNotResolvedException()

        mpd_headers = {
            "Origin": self._url,
            "Referer": self._url,
            "User-Agent": UA,
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
        }
        drm_la_headers = {
            "Origin": self._url,
            "Referer": self._url,
            "Content-Type": "application/octet-stream",
            "User-Agent": UA,
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
        }

        return {
            "protocol": "mpd",
            "path": requests.utils.requote_uri(stream["url"])
            + "|"
            + self._headers_str(mpd_headers),
            "drm": "com.widevine.alpha",
            "key": stream["drm"]["laurl"]
            + "|"
            + self._headers_str(drm_la_headers)
            + "|R{SSM}|",
        }

    def pin_info(self,pin):     # updated to new API
        """Returns pin info
        :return:
        """
        self._login()
        res = self._post("/pin/parental/verify", {"pin": pin})
        return str(res)

    def devices(self, remove_device=""): # Old code not needed, handled differently in _session
        """Returns devices info
        :return:
        """

        def tidy_devices(devices_info):
            r = []
            for data in devices_info:
                r.append(
                    {
                        "id": data["s"],
                        "name": data["n"],
                        "type": data["t"],
                        "lastactivity": data["a"],
                    }
                )
            return r

        self._login()
        if remove_device != "":
            res = self._get(
                {"z": "devices", "lng": self._lang, "a": self._app, "rm": remove_device}
            )
        else:
            res = self._get({"z": "devices", "lng": self._lang, "a": self._app})
        return tidy_devices(res.json())

    def library(self, endpoint, parameters):         # updated to new API
        #logger.log.info("Spejlo - sky " + json.dumps(endpoint) + json.dumps(parameters))
        self._login()
        res = self._get(endpoint, parameters)
        data = res.json()
        return data

